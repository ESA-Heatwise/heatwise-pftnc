from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, model_validator


class InferenceModelConfig(BaseModel):
    bundle_path: Path
    selection: Literal[
        "best_overall",
        "best_per_target",
        "ensemble_simple",
        "ensemble_weighted",
        "ensemble_weighted_per_target",
    ] = "best_overall"


class InferenceInputConfig(BaseModel):
    path: Path


class InferenceConfig(BaseModel):
    model: InferenceModelConfig
    input_dataset: InferenceInputConfig
    save_model_inputs: bool = True
    mode: Literal["latest", "from_date"] = "latest"
    start_date: date | None = None
    output_path: Path

    @model_validator(mode="after")
    def validate_date_selection(self) -> "InferenceConfig":
        if self.mode == "from_date" and not self.start_date:
            raise ValueError("start_date is required when mode='from_date'")
        if self.mode == "latest" and self.start_date is not None:
            raise ValueError("start_date is only valid when mode='from_date'")
        return self


def load_inference_config(path: str | Path) -> InferenceConfig:
    """Load inference configuration and resolve paths relative to its file."""
    path = Path(path).resolve()
    with path.open("r") as stream:
        raw = yaml.safe_load(stream) or {}

    config_dir = path.parent
    model = raw["model"]
    input_dataset = raw["input_dataset"]
    for section, key in ((model, "bundle_path"), (input_dataset, "path")):
        value = Path(section[key])
        section[key] = str(
            value if value.is_absolute() else (config_dir / value).resolve()
        )

    output = Path(raw["output_path"])
    raw["output_path"] = str(
        output if output.is_absolute() else (config_dir / output).resolve()
    )
    return InferenceConfig(**raw)
