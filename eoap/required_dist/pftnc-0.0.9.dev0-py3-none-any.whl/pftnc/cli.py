import logging
import shutil
from importlib import resources
from pathlib import Path

import typer

from pftnc.logging import setup_logger

setup_logger()

logger = logging.getLogger(__name__)

app = typer.Typer(help="PFTNC (Phytoplankton Functional Types - NowCasting) CLI")

PACKAGE_CONFIG_DIR = Path(str(resources.files("pftnc") / "config"))


@app.command(
    help="""
    Generate simulated datasets from raw observations using the
    configured sensor simulations, revisit schedules, cloud masking,
    and noise models.
    """
)
def simulate(config_path: Path):
    """
    Generate simulated datasets from raw observations.
    """
    from pftnc.dataset_simulation_config import load_dataset_gen_config
    from pftnc.simulation.simulate import simulate_dataset

    typer.echo("Loading simulation configuration...")
    config = load_dataset_gen_config(config_path)

    typer.echo("Running dataset simulation pipeline...")
    output_path = simulate_dataset(config)

    typer.secho(
        f"Simulation completed successfully.\nDataset saved at:\n{output_path}",
        fg=typer.colors.GREEN,
        bold=True,
    )


@app.command(
    help="""
    Run preprocessing and feature engineering pipeline on a dataset.
    """
)
def preprocess(config_path: Path):
    """
    Run feature engineering pipeline.
    """
    from pftnc.preprocess.preprocess import preprocess_dataset

    from .config import load_config

    typer.echo("Loading preprocessing configuration...")
    config = load_config(config_path)

    typer.echo("Running preprocessing pipeline...")
    artifact = preprocess_dataset(config.feature_engineering)

    typer.secho(
        f"Preprocessing completed successfully.\nDataset saved at:\n"
        f"{str(artifact.base_path / artifact.version)}",
        fg=typer.colors.GREEN,
        bold=True,
    )


@app.command(
    help="""
    Create example configuration files in a target directory.

    By default, packaged configs are copied into ./config.

    Optionally provide:
    --source-path to copy configs from another directory.
    --output-path to control destination location.
    """
)
def create_config(
    output_path: Path = typer.Option(
        Path("./config"),
        help="Directory where config files will be copied.",
    ),
    source_path: Path | None = typer.Option(
        None,
        help="Optional source config directory to copy from.",
    ),
):
    """
    Copy template configuration files.
    """
    if source_path is None:
        source_dir = PACKAGE_CONFIG_DIR
        logger.info(
            "Using packaged configuration templates from %s",
            source_dir,
        )

    else:
        source_dir = source_path.resolve()

        if not source_dir.exists():
            logger.error(
                "Source config path does not exist: %s",
                source_dir,
            )

            raise typer.BadParameter(f"Source config path not found: {source_dir}")

        logger.info(
            "Using user-provided config source: %s",
            source_dir,
        )

    output_dir = output_path.resolve()
    logger.info(
        "Creating config directory at %s",
        output_dir,
    )

    output_dir.mkdir(parents=True, exist_ok=True)

    copied_files = []

    to_be_copied_files = [
        "config.yml",
        "dataset_simulation_config.yml",
        "inference.yml",
    ]

    for filename in to_be_copied_files:
        source_file = source_dir / filename
        destination = output_dir / filename
        shutil.copy2(source_file, destination)
        copied_files.append(destination)
        logger.info(
            "Copied %s -> %s",
            source_file,
            destination,
        )

    if not copied_files:
        logger.error(
            "No YAML config files found in %s",
            source_dir,
        )

        raise typer.BadParameter(f"No config files found in {source_dir}")

    typer.secho(
        f"Successfully copied {len(copied_files)} config file(s) to:\n{output_dir}",
        fg=typer.colors.GREEN,
        bold=True,
    )


@app.command(
    help="""
    Run training pipeline using the provided config file.

    This executes the training workflow including:
    - dataset loading
    - fold-based training
    - tuning (if enabled)
    - evaluation and logging
    """
)
def train(config_path: Path):
    """
    Run model training pipeline.
    """

    logger.info(
        "[TRAINING PIPELINE] Starting training pipeline... loading libraries and config..."
    )

    if not config_path.exists():
        config_not_found_error = f"Config file not found: {config_path}"
        logger.error("[CONFIG] %s", config_not_found_error)
        raise typer.BadParameter(config_not_found_error)

    logger.info("[CONFIG] Loading training configuration")
    from pftnc.config import load_config

    config = load_config(config_path)

    logger.info("[PIPELINE] Running training pipeline")
    from pftnc.train.train import run_training

    run_training(config, config_path)
    logger.info("[PIPELINE] Training completed successfully")


@app.command("package-model")
def package_model(
    training_run_path: Path = typer.Option(
        ...,
        "--training-run-path",
        "--training_run_path",
        help="Completed training run directory containing run_summary.json.",
    ),
    output_path: Path = typer.Option(
        ...,
        "--output-path",
        "--output_path",
        help="New directory where the inference bundle will be created.",
    ),
):
    """Create a portable inference bundle from a completed training run."""
    from pftnc.predict.bundle import package_model_bundle

    bundle = package_model_bundle(training_run_path, output_path)
    typer.secho(
        f"Model bundle created successfully at:\n{bundle}",
        fg=typer.colors.GREEN,
        bold=True,
    )


@app.command("infer")
def infer(config_path: Path):
    """Run config-driven inference using a packaged model bundle."""
    from pftnc.inference_config import load_inference_config
    from pftnc.predict.inference import run_inference

    config = load_inference_config(config_path)
    result = run_inference(config)
    typer.secho(
        f"Inference completed successfully.\nRows: {len(result)}\n"
        f"Predictions saved at:\n{config.output_path}",
        fg=typer.colors.GREEN,
        bold=True,
    )


if __name__ == "__main__":
    app()
