from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

import yaml

from pftnc.provenance import build_provenance, workspace_root

MANIFEST_NAME = "manifest.yml"


def _read_yaml(path: Path) -> dict[str, Any]:
    with path.open() as stream:
        value = yaml.safe_load(stream) or {}
    if not isinstance(value, dict):
        raise ValueError(f"Expected a mapping in {path}")
    return value


def package_model_bundle(training_run_path: Path, output_path: Path) -> Path:
    """Copy runtime artifacts from a completed training run into a bundle."""
    training_run_path = training_run_path.expanduser().resolve()
    output_path = output_path.expanduser().resolve()
    required = {
        "summary": training_run_path / "run_summary.json",
        "config": training_run_path / "config.yml",
        "schema": training_run_path / "model_io_schema.yml",
        "selection": training_run_path / "model_selection.yml",
    }
    for name, path in required.items():
        if not path.exists():
            raise FileNotFoundError(f"Required {name} artifact not found: {path}")

    summary = json.loads(required["summary"].read_text())
    config = _read_yaml(required["config"])
    schema = _read_yaml(required["schema"])
    selection = _read_yaml(required["selection"])
    dataset_path = Path(summary["dataset_path"]).expanduser().resolve()
    dataset_config = _read_yaml(dataset_path / "config.yml")
    dataset_metadata = _read_yaml(dataset_path / "metadata.yml")
    provenance_path = dataset_path / "provenance.yml"
    if provenance_path.exists():
        dataset_provenance = _read_yaml(provenance_path)
    else:
        # Older dataset artifacts may not contain provenance.yml. Reconstruct
        # their lineage from the training input reference and stored dataset
        # configuration; the current training run still provides the required
        # model_io_schema.yml.
        training_input = config.get("training", {}).get("input_dataset", {})
        if all(
            training_input.get(key) is not None
            for key in ("base_path", "registry_path", "version")
        ):
            bundle_workspace = workspace_root(training_run_path)
            base_path = Path(training_input["base_path"])
            registry_path = Path(training_input["registry_path"])
            if not base_path.is_absolute():
                base_path = bundle_workspace / base_path
            if not registry_path.is_absolute():
                registry_path = bundle_workspace / registry_path
            dataset_provenance = build_provenance(
                kind="feature_engineered",
                base_path=base_path,
                registry_path=registry_path,
                version=training_input["version"],
                config=dataset_config,
            )
        else:
            dataset_provenance = {}

    if output_path.exists():
        if not output_path.is_dir() or any(output_path.iterdir()):
            raise FileExistsError(
                f"Bundle output must be a new empty directory: {output_path}"
            )
    output_path.mkdir(parents=True, exist_ok=True)

    folds: dict[str, Any] = {}
    training_metrics: dict[str, Any] = {}
    mlflow_uris: dict[str, Any] = {}
    for fold_name, fold in summary.get("folds", {}).items():
        if fold_name in {"trainer_run_id", "dataset_version", "dataset_path"}:
            continue
        raw_paths = fold["model_path"]
        paths = (
            {"__multi_target__": raw_paths} if isinstance(raw_paths, str) else raw_paths
        )
        packaged: dict[str, str] = {}
        for model_name, raw_path in paths.items():
            source = Path(raw_path).expanduser().resolve()
            if not source.is_file():
                raise FileNotFoundError(f"Model artifact does not exist: {source}")
            destination = output_path / "models" / fold_name / source.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            packaged[model_name] = destination.relative_to(output_path).as_posix()
        folds[fold_name] = {"models": packaged}
        training_metrics[fold_name] = {
            "train": fold.get("train_metrics", {}),
            "validation": fold.get("val_metrics", {}),
            "test": fold.get("test_metrics", {}),
        }
        mlflow_uris[fold_name] = fold.get("model_uri")

    manifest = {
        "model_type": config["training"]["model"]["type"],
        "model_mode": summary["model_mode"],
        "dataset_version": summary["dataset_version"],
        "model_io": schema,
        "dataset_metadata": dataset_metadata,
        "feature_engineering": dataset_config.get("features", {}),
        "feature_selection": config["training"].get("feature_selection", {}),
        "target_transformations": config["training"].get("target_transformations", {}),
        "selection": selection,
        "folds": folds,
    }
    with (output_path / MANIFEST_NAME).open("w") as stream:
        stream.write(
            "# Created from the pftnc-experiments repository with pftnc-data "
            "checked out alongside it under the same workspace root.\n"
        )
        yaml.safe_dump(manifest, stream, sort_keys=False)

    with (output_path / "training_metrics.yml").open("w") as stream:
        yaml.safe_dump(
            {"folds": training_metrics, "final_test": summary.get("final_test", {})},
            stream,
            sort_keys=False,
        )
    with (output_path / "provenance.yml").open("w") as stream:
        yaml.safe_dump(
            {
                "created_from": "pftnc-experiments",
                "source_experiment": summary.get("trainer_run_id"),
                "dataset_version": summary.get("dataset_version"),
                "dataset_lineage": dataset_provenance,
                "mlflow_model_uris": mlflow_uris,
            },
            stream,
            sort_keys=False,
        )
    return output_path


def load_manifest(bundle_path: Path) -> dict[str, Any]:
    bundle_path = bundle_path.expanduser().resolve()
    manifest_path = bundle_path / MANIFEST_NAME
    if not manifest_path.exists():
        raise FileNotFoundError(f"Model bundle manifest not found: {manifest_path}")
    manifest = _read_yaml(manifest_path)
    if not manifest.get("folds"):
        raise ValueError("Model bundle contains no fold models")
    return manifest
