"""Portable dataset lineage and path serialization."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

import yaml

from pftnc.utils.utils import get_registry_key_and_paths, read_registry


def repository_root(path: Path) -> Path:
    """Return the git repository containing *path* (or its nearest parent)."""
    candidate = path if path.is_dir() else path.parent
    for parent in (candidate, *candidate.parents):
        if (parent / ".git").exists():
            return parent
    return candidate


def workspace_root(path: Path) -> Path:
    """Repositories are expected to be siblings below one workspace root."""
    return repository_root(path).parent


def portable_path(path: str | Path, *, root: Path) -> str:
    """Serialize a path without exposing an absolute filesystem location."""
    value = Path(path)
    if value.is_absolute():
        try:
            return value.resolve().relative_to(root.resolve()).as_posix()
        except ValueError as exc:
            raise ValueError(
                f"Path {value} is outside the workspace root {root}; "
                "provenance only supports sibling repositories."
            ) from exc
    return value.as_posix()


def portable_config(value: Any, *, root: Path) -> Any:
    """Convert absolute paths in a config snapshot to workspace-relative paths."""
    if isinstance(value, dict):
        return {key: portable_config(item, root=root) for key, item in value.items()}
    if isinstance(value, list):
        return [portable_config(item, root=root) for item in value]
    if isinstance(value, str) and Path(value).is_absolute():
        return portable_path(value, root=root)
    return value


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def direct_input_reference(path: Path, *, root: Path) -> dict[str, Any]:
    if path.is_dir():
        candidates = list(path.glob("*.parquet")) + list(path.glob("*.csv"))
        if len(candidates) != 1:
            raise ValueError(
                f"Expected exactly one CSV or Parquet input in {path}; "
                f"found {len(candidates)}"
            )
        path = candidates[0]
    if not path.is_file():
        raise FileNotFoundError(f"Direct provenance input does not exist: {path}")
    repo = repository_root(path)
    return {
        "repository": repo.name,
        "path": path.resolve().relative_to(repo.resolve()).as_posix(),
        "sha256": file_sha256(path),
    }


def registry_reference(
    *, base_path: Path, registry_path: Path, version: str
) -> dict[str, Any]:
    repo = repository_root(registry_path)
    return {
        "repository": repo.name,
        "base_path": base_path.resolve().relative_to(repo.resolve()).as_posix(),
        "registry_path": registry_path.resolve().relative_to(repo.resolve()).as_posix(),
        "version": version,
    }


def _artifact_path(base_path: Path, registry_path: Path, version: str) -> Path:
    registry = read_registry(registry_path)
    key, _ = get_registry_key_and_paths(registry_path, base_path)
    entry = registry.get("datasets", {}).get(key, {}).get(version)
    if entry is None:
        raise ValueError(f"Dataset version {version!r} is not registered for {key!r}")
    configured = Path(entry.get("path", ""))
    repo = repository_root(registry_path)
    artifact = configured if configured.is_absolute() else repo / configured
    if not artifact.exists():
        raise FileNotFoundError(
            f"Registered dataset artifact does not exist: {artifact}"
        )
    return artifact.resolve()


def _resolve_input(input_config: dict[str, Any], *, root: Path) -> dict[str, Any]:
    if input_config.get("path") is not None:
        path = Path(input_config["path"])
        if not path.is_absolute():
            path = root / path
        reference = direct_input_reference(path, root=root)
        return {"stage": "raw_input", **reference}

    base_path = Path(input_config["base_path"])
    registry_path = Path(input_config["registry_path"])
    if not base_path.is_absolute():
        base_path = root / base_path
    if not registry_path.is_absolute():
        registry_path = root / registry_path
    version = input_config.get("version")
    if version is None:
        raise ValueError("Provenance requires an explicit dataset version")
    artifact = _artifact_path(base_path, registry_path, version)
    reference = registry_reference(
        base_path=base_path, registry_path=registry_path, version=version
    )
    config_path = artifact / "config.yml"
    if not config_path.exists():
        raise FileNotFoundError(
            f"Registered artifact config does not exist: {config_path}"
        )
    config = yaml.safe_load(config_path.read_text()) or {}
    if "simulation" in config:
        stage = "simulation"
    elif "features" in config and "output_dataset" in config:
        stage = "feature_engineering"
    else:
        raise ValueError(
            f"Cannot determine provenance stage from artifact config: {config_path}"
        )
    result = {"stage": stage, **reference}
    if "input_dataset" in config:
        result["inputs"] = [_resolve_input(config["input_dataset"], root=root)]
    elif "simulation" in config and config["simulation"]:
        simulation_input = config["simulation"].get("input_path")
        if simulation_input is None:
            raise ValueError(f"Simulation config has no input_path: {config_path}")
        path = Path(simulation_input)
        if not path.is_absolute():
            path = root / path
        result["inputs"] = [_resolve_input({"path": str(path)}, root=root)]
    return result


def build_provenance(
    *,
    kind: str,
    base_path: Path,
    registry_path: Path,
    version: str,
    config: dict[str, Any],
) -> dict[str, Any]:
    root = workspace_root(registry_path)
    artifact_reference = registry_reference(
        base_path=base_path, registry_path=registry_path, version=version
    )
    lineage = {
        "stage": kind,
        **artifact_reference,
    }
    if "input_dataset" in config:
        lineage["inputs"] = [_resolve_input(config["input_dataset"], root=root)]
    else:
        lineage["inputs"] = [
            _resolve_input({"path": config["simulation"]["input_path"]}, root=root)
        ]

    return {
        "repository_layout": "sibling_repositories_under_common_parent",
        "lineage": lineage,
    }


def write_provenance(path: Path, payload: dict[str, Any]) -> None:
    with path.open("w") as stream:
        yaml.safe_dump(payload, stream, sort_keys=False)
