import json
import os
import subprocess
import uuid
from datetime import UTC, datetime
from hashlib import sha1
from pathlib import Path
from pprint import pprint
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

import pandas as pd
import yaml

if TYPE_CHECKING:
    from mypy_boto3_s3.client import S3Client


def get_or_create_experiment(experiment_name: str):
    """
    Retrieve the ID of an existing MLflow experiment or create a new one if it doesn't exist.

    This function checks if an experiment with the given name exists within MLflow.
    If it does, the function returns its ID. If not, it creates a new experiment
    with the provided name and returns its ID.

    Taken from mlflow.org

    Parameters:
    - experiment_name (str): Name of the MLflow experiment.

    Returns:
    - str: ID of the existing or newly created MLflow experiment.
    """
    import mlflow

    if experiment := mlflow.get_experiment_by_name(experiment_name):
        return experiment.experiment_id
    else:
        return mlflow.create_experiment(experiment_name)


def get_s3_client(endpoint_url: str, access_key: str, secret_key: str) -> "S3Client":
    """
    Create a boto3 S3 client configured for MinIO
    """
    import boto3

    return boto3.client(
        "s3",
        endpoint_url=endpoint_url,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
        verify=False,  # For local MinIO. Set to True for production
    )


def get_latest_data_path(
    s3_client: "S3Client", bucket_name: str, base_folder: str = "preprocessing"
) -> tuple[str, str]:
    """
    Find the latest timestamp folder and NPZ file in the specified bucket/folder
    Returns tuple of (full_path, filename)
    """
    response = s3_client.list_objects_v2(
        Bucket=bucket_name, Prefix=f"{base_folder}/", Delimiter="/"
    )

    timestamps = []
    for prefix in response.get("CommonPrefixes", []):
        folder_name = prefix["Prefix"].strip("/")
        try:
            timestamp = folder_name.replace(f"{base_folder}/", "")
            timestamps.append(timestamp)
        except ValueError:
            continue

    if not timestamps:
        raise ValueError("No timestamp folders found")

    latest_timestamp = sorted(timestamps)[-1]
    latest_folder = f"{base_folder}/{latest_timestamp}"

    response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=latest_folder)

    npz_files = [
        obj["Key"]
        for obj in response.get("Contents", [])
        if obj["Key"].endswith(".npz")
    ]

    if not npz_files:
        raise ValueError(f"No NPZ files found in {latest_folder}")

    latest_file = npz_files[0]
    return latest_file, latest_file.split("/")[-1]


def show_datasets_info(run_id: str):
    """
    Display readable information about all datasets used in an MLflow run
    """
    import mlflow

    run = mlflow.get_run(run_id)
    datasets = run.inputs.dataset_inputs

    print(f"Number of datasets used: {len(datasets)}\n")
    if "data_source" in run.data.params:
        print(f"Data Source: {run.data.params['data_source']}")
    for dataset_input in datasets:
        dataset = dataset_input.dataset
        tags = dataset_input.tags

        info = {
            "Role": tags[0].value,
            "Digest": dataset.digest,
            "Name": dataset.name,
            "Profile": json.loads(dataset.profile),
            "Schema": json.loads(dataset.schema),
            "Source": json.loads(dataset.source),
        }

        print(f"Dataset (Role: {info['Role']}):")
        pprint(info, indent=2, width=100)
        print("\n" + "=" * 80 + "\n")


def read_registry(regsitry_path: Path) -> dict[str, Any]:
    """
    Load dataset registry YAML file.

    Args:
        registry_path: Path to registry YAML file.

    Returns:
        Registry dictionary with dataset metadata.
    """
    if regsitry_path.exists():
        data = yaml.safe_load(regsitry_path.read_text())

        if data is None:
            data = {"datasets": {}}

        return data

    else:
        return {"datasets": {}}


def get_registry_key_and_paths(
    registry_path: Path, base_path: Path
) -> tuple[str, Path]:
    """
    Helper to extract a uniform registry key and an absolute disk dataset path.
    """
    abs_base_path = base_path.resolve()

    project_root = None
    root_indicators = {"pixi.toml", "pyproject.toml", "setup.py", ".git", ".pixi"}

    for parent in registry_path.resolve().parents:
        if any((parent / indicator).exists() for indicator in root_indicators):
            project_root = parent
            break

    if project_root is None:
        project_root = registry_path.resolve().parent

    base_key = os.path.relpath(abs_base_path, project_root).replace("\\", "/")

    if base_key == ".":
        base_key = abs_base_path.name

    return base_key, abs_base_path


def validate_registry(
    registry_path: Path,
    base_path: Path,
) -> None:
    """
    Validate that registry versions match dataset folders on disk.

    Args:
        registry_path: Dataset registry path.
        base_path: Dataset base directory.

    Raises:
        RuntimeError: If disk and registry versions differ.
    """
    registry = read_registry(registry_path)
    base_key, abs_base_path = get_registry_key_and_paths(registry_path, base_path)

    disk_versions = (
        {p.name for p in abs_base_path.iterdir() if p.is_dir()}
        if abs_base_path.exists()
        else set()
    )

    yaml_versions = set(registry.get("datasets", {}).get(base_key, {}).keys())

    if disk_versions != yaml_versions:
        raise RuntimeError(
            "Dataset registry mismatch\n"
            f"Dataset: {base_key}\n"
            f"Disk versions: {sorted(disk_versions)}\n"
            f"Registry versions: {sorted(yaml_versions)}"
        )


def generate_dataset_version(
    cfg: Any,
    site: str,
) -> str:
    """
    Generate a unique dataset version identifier.

    Args:
        cfg: Dataset configuration object.
        site: Site or dataset identifier.

    Returns:
        Unique dataset version string.
    """
    timestamp = datetime.now().strftime("%Y%m%dT%H%M%SZ%z")

    # stable hash of config - if multiple users created the dataset using same configurations
    cfg_dict = cfg.model_dump(mode="json")
    cfg_json = json.dumps(cfg_dict, sort_keys=True)
    cfg_hash = sha1(cfg_json.encode()).hexdigest()[:8]

    # randomness prevents collisions
    rand = uuid.uuid4().hex[:6]

    return f"{site}_{timestamp}_{cfg_hash}_{rand}"


def register_dataset_version(
    registry_path: Path,
    base_path: Path,
    description: str,
    version: str,
) -> None:
    """
    Register a dataset version in the YAML registry.

    Args:
        registry_path: Path to registry YAML file.
        base_path: Base dataset directory.
        description: Human-readable dataset description.
        version: Dataset version identifier.
    """
    registry = read_registry(registry_path)
    base_key, _ = get_registry_key_and_paths(registry_path, base_path)

    if "datasets" not in registry:
        registry["datasets"] = {}

    if base_key not in registry["datasets"]:
        registry["datasets"][base_key] = {}

    registry["datasets"][base_key][version] = {
        "path": "/".join([base_key, version]),
        "description": description,
        "created": datetime.now(UTC).isoformat(),
    }

    registry_path.parent.mkdir(parents=True, exist_ok=True)

    with registry_path.open("w") as f:
        yaml.safe_dump(registry, f, sort_keys=False)


def save_feature_schema(
    df: "pd.DataFrame",
    path: Path,
) -> None:
    """
    Save dataframe feature schema metadata to YAML.

    Args:
        df: Feature dataframe.
        path: Output directory path.
    """
    schema = {"columns": list(df.columns), "n_features": len(df.columns)}

    with open(path / "feature_schema.yml", "w") as f:
        yaml.safe_dump(schema, f)


def check_target_quality(
    df: pd.DataFrame,
    target_cols: list[str],
) -> None:
    """
    Raise if any target column contains NaN or negative values.

    Call this on the prepared dataframe before build_dataset.
    Negative concentrations are physically invalid and cause NaN in the
    log-fractions transform; NaN targets have no valid label.
    """
    issues = {}
    nan_counts = df[target_cols].isna().sum()
    neg_counts = (df[target_cols] < 0).sum()
    if nan_counts.any():
        issues["nan"] = nan_counts[nan_counts > 0].to_dict()
    if neg_counts.any():
        issues["negative"] = neg_counts[neg_counts > 0].to_dict()
    if issues:
        raise ValueError(
            "Target quality check failed:\n"
            + "\n".join(f"  {k}: {v}" for k, v in issues.items())
            + "\nFix the data before calling build_dataset."
        )
    print(f"Target quality OK — {len(df)} rows, no NaN or negative values in targets.")


def save_pixi_package_versions(
    output_path: str | Path = "versions.txt",
) -> None:
    """
    Save installed Pixi package versions to a text file during the execution
    of a pipeline step.

    Args:
        output_path: Output file path for package versions.
    """
    result = subprocess.run(
        ["pixi", "list"],
        capture_output=True,
        text=True,
        check=True,
    )

    Path(output_path).write_text(result.stdout)


def is_url(value: str) -> bool:
    """
    Return True if value is an HTTP/HTTPS URL.
    """
    parsed = urlparse(str(value))

    return parsed.scheme in {"http", "https"}


def resolve_path(
    path_value: str | Path,
    config_dir: Path,
) -> str:
    """
    Resolve relative filesystem paths against the config directory.

    URLs are returned unchanged.

    Args:
        path_value: Relative path, absolute path, or URL.
        config_dir: Directory containing the config file.

    Returns:
        Resolved absolute path or original URL.
    """
    if is_url(str(path_value)):
        return str(path_value)

    path = Path(path_value)

    if not path.is_absolute():
        path = config_dir / path

    return str(path.resolve())
